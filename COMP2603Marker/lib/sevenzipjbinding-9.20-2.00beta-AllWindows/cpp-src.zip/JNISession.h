/*
 * JNISession.h
 *
 *  Created on: Jan 16, 2010
 *      Author: boris
 */

#ifndef JNISESSION_H_
#define JNISESSION_H_

#include <list>
#include <map>
#include <new>

//#include "Common/MyWindows.h"
// TODO Remove file

#endif /* JNISESSION_H_ */
