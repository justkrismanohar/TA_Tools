/**
 * This package contains simplified interface of 7-Zip-JBinding. This interface is more java-like,
 * but don't provide access to all 7-Zip features.
 * 
 * @see net.sf.sevenzipjbinding.simple
 * 
 * @author Boris Brodski
 * @since 4.65-1
 */
package net.sf.sevenzipjbinding.simple;

