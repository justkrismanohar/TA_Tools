/**
 * This package contains implementation of the simplified interface of 7-Zip-JBinding, defined in
 * {@link net.sf.sevenzipjbinding.simple}.
 * 
 * @see net.sf.sevenzipjbinding.simple
 * 
 * @author Boris Brodski
 * @since 4.65-1
 */
package net.sf.sevenzipjbinding.simple.impl;

